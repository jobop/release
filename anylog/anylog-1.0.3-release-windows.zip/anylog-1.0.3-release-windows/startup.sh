nohup java -Djava.ext.dirs="lib/:providers/" -DappHome="conf" -jar lib/anylog-base-1.0.3.jar 52808 $@ >>logs/anylog.log   &
echo $!>pid

